#include "hse_b_catalog_formatting.h"
#include "hse_mu.h"


bool_t IsKeyCatalogFormatted(void)
{
    return CHECK_HSE_STATUS(HSE_STATUS_INSTALL_OK);
  
}



